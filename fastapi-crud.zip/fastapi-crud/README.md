# CRUD Benchmark - Python + FastAPI + SQLAlchemy + MySQL

Implementación en Python del CRUD de productos usado como benchmark comparativo contra Go, Rust, NestJS y Elysia.

## Stack

- **Framework:** [FastAPI](https://fastapi.tiangolo.com/) 0.115
- **Base de datos:** MySQL, vía SQLAlchemy 2.0 en modo **async** + driver `aiomysql` (pure-Python, sin dependencias de compilación)
- **Validación:** Pydantic v2
- **Servidor ASGI:** Uvicorn
- **Documentación:** Swagger UI nativo de FastAPI, reubicado en `/api`

## Variables de entorno (`.env`)

```dotenv
ENV_URL_MYSQL_DB=mysql://root:my-secret-pw@127.0.0.1:3306/crud_benchmark
APP_PORT=8083
```

> Nota: usé el puerto **8083** para que no choque con Go (`8081`) y Rust (`8082`). Cambia `APP_PORT` si prefieres otro.

Igual que en Go, `app/database.py` convierte la URL `mysql://...` al formato que necesita el driver async: `mysql+aiomysql://...`. SQLAlchemy no acepta el esquema `mysql://` a secas para modo asíncrono, por eso existe `build_async_url()`.

## Preparar la base de datos

Si ya tienes `crud_benchmark` creada (de los proyectos anteriores), no necesitas hacer nada más — la tabla `products` se crea sola al arrancar (equivalente al `AutoMigrate` de Go y al `CREATE TABLE IF NOT EXISTS` de Rust).

Si es la primera vez:

```sql
CREATE DATABASE IF NOT EXISTS crud_benchmark CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

## Instalar y correr en local

```bash
# Crear entorno virtual (recomendado)
python3 -m venv venv
source venv/bin/activate

# Instalar dependencias
pip install -r requirements.txt

# Correr el servidor
python run.py
```

Deberías ver algo como:
```
✅ Conexión a MySQL establecida y tabla verificada correctamente
INFO:     Uvicorn running on http://0.0.0.0:8083
```

Si tu sistema marca el entorno como "externally managed" (Ubuntu 23.04+/Debian 12+) y no quieres usar `venv`, instala con:

```bash
pip install -r requirements.txt --break-system-packages
```

## Swagger

Abre en el navegador:

```
http://localhost:8083/api
```

El JSON crudo del esquema OpenAPI queda en `http://localhost:8083/openapi.json` (comportamiento por defecto de FastAPI).

## Probar los endpoints con curl

```bash
# Crear producto
curl -X POST http://localhost:8083/products \
  -H "Content-Type: application/json" \
  -d '{"name":"Mouse inalámbrico","price":45.50,"stock":40}'

# Listar todos
curl http://localhost:8083/products

# Obtener por ID
curl http://localhost:8083/products/1

# Actualizar (campos parciales, todos opcionales)
curl -X PUT http://localhost:8083/products/1 \
  -H "Content-Type: application/json" \
  -d '{"stock":55}'

# Eliminar
curl -X DELETE http://localhost:8083/products/1

# Health check
curl http://localhost:8083/health
```

## Docker

```bash
docker build -t crud-fastapi .

docker run -d -p 8083:8083 \
  --add-host=host.docker.internal:host-gateway \
  -e ENV_URL_MYSQL_DB="mysql://root:my-secret-pw@host.docker.internal:3306/crud_benchmark" \
  -e APP_PORT=8083 \
  crud-fastapi
```

El `--add-host` es necesario porque MySQL corre en tu máquina host, no en un contenedor; sin ese flag, el contenedor no puede alcanzar `127.0.0.1` de tu equipo.

## Estructura del proyecto

```
fastapi-crud/
├── requirements.txt
├── run.py                  # entry point: lee APP_PORT y levanta uvicorn
├── .env
├── .gitignore
├── Dockerfile
├── README.md
└── app/
    ├── __init__.py
    ├── main.py              # instancia FastAPI, lifespan (crea tabla), monta /api
    ├── database.py          # engine async + conversión de ENV_URL_MYSQL_DB
    ├── models.py             # modelo SQLAlchemy Product
    ├── schemas.py            # esquemas Pydantic (Create/Update/Out)
    └── routers/
        ├── __init__.py
        └── products.py       # los 5 endpoints CRUD
```

## Validado en este entorno

Este proyecto fue probado en el sandbox: se instalaron todas las dependencias con `pip` y se confirmó que la aplicación carga sin errores, con las 5 rutas del CRUD, `/health` y `/api` (Swagger) correctamente registradas.
