import os
from urllib.parse import urlparse

from dotenv import load_dotenv
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import declarative_base

load_dotenv()


def build_async_url(raw_url: str) -> str:
    """
    Convierte una URL estilo "mysql://user:pass@host:port/db" (ENV_URL_MYSQL_DB)
    al formato que espera SQLAlchemy async con el driver aiomysql:
    "mysql+aiomysql://user:pass@host:port/db".
    """
    parsed = urlparse(raw_url)
    if parsed.scheme != "mysql":
        raise ValueError(f"Esquema de conexión no soportado: {parsed.scheme}")

    return raw_url.replace("mysql://", "mysql+aiomysql://", 1)


_raw_url = os.getenv("ENV_URL_MYSQL_DB")
if not _raw_url:
    raise RuntimeError("La variable de entorno ENV_URL_MYSQL_DB no está definida")

DATABASE_URL = build_async_url(_raw_url)

engine = create_async_engine(
    DATABASE_URL,
    echo=False,
    pool_size=50,
    max_overflow=10,
    pool_pre_ping=True,
)

AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False)

Base = declarative_base()


async def get_db():
    """Dependency de FastAPI: entrega una sesión de BD por request."""
    async with AsyncSessionLocal() as session:
        yield session
