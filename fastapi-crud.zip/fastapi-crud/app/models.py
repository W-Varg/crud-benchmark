from sqlalchemy import TIMESTAMP, BigInteger, Column, Float, Integer, String, func

from app.database import Base


class Product(Base):
    """
    Entidad Product tal como se almacena en MySQL.
    Se mantiene idéntica en estructura a las versiones de Go, Rust,
    NestJS y Elysia para que la comparación de benchmark sea justa.
    """

    __tablename__ = "products"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    name = Column(String(150), nullable=False)
    price = Column(Float, nullable=False)
    stock = Column(Integer, nullable=False, default=0)
    created_at = Column(TIMESTAMP, server_default=func.now())
    updated_at = Column(TIMESTAMP, server_default=func.now(), onupdate=func.now())
