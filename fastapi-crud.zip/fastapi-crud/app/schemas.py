from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class ProductBase(BaseModel):
    name: str = Field(..., max_length=150, examples=["Laptop"])
    price: float = Field(..., gt=0, examples=[1200.50])
    stock: int = Field(..., ge=0, examples=[10])


class ProductCreate(ProductBase):
    pass


class ProductUpdate(BaseModel):
    """Todos los campos son opcionales: se actualiza solo lo que se envía."""

    name: Optional[str] = Field(None, max_length=150)
    price: Optional[float] = Field(None, gt=0)
    stock: Optional[int] = Field(None, ge=0)


class ProductOut(ProductBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    created_at: datetime
    updated_at: datetime


class MessageResponse(BaseModel):
    message: str
