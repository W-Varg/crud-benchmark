from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.database import Base, engine
from app.routers import products


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Equivalente al AutoMigrate de GORM (Go) o al CREATE TABLE IF NOT EXISTS de sqlx (Rust)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print("✅ Conexión a MySQL establecida y tabla verificada correctamente")
    yield


app = FastAPI(
    title="CRUD Benchmark API - Python + FastAPI + SQLAlchemy + MySQL",
    version="1.0.0",
    description=(
        "API CRUD de productos usada como benchmark de rendimiento "
        "entre Go, Python, NestJS, Rust y Elysia."
    ),
    docs_url="/api",       # Swagger UI servido en /api en vez de /docs
    redoc_url=None,
    lifespan=lifespan,
)

app.include_router(products.router)


@app.get("/health", tags=["health"])
async def health():
    return {"status": "ok"}
