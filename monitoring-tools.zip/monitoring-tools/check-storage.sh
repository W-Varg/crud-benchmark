#!/bin/bash
# Reporta el peso de las imágenes del benchmark y qué % ocupan
# de tu presupuesto de storage (por defecto 5 GB).

BUDGET_MB=${1:-5120}  # 5120 MB = 5 GB

echo "=== Peso de imágenes del benchmark ==="
docker images --format "{{.Repository}}:{{.Tag}}\t{{.Size}}" | grep -E "go_crud|rust_crud|python_crud|bun_crud|nestjs_crud"

echo ""
echo "=== Detalle con capas (build cache incluido) ==="
docker system df -v | grep -E "REPOSITORY|go_crud|rust_crud|python_crud|bun_crud|nestjs_crud"

echo ""
TOTAL_BYTES=$(docker images --format "{{.Repository}} {{.Size}}" \
  | grep -E "go_crud|rust_crud|python_crud|bun_crud|nestjs_crud" \
  | awk '{
      size=$2;
      # separa el número del sufijo de unidad (ej: "292MB" -> 292 y "MB")
      match(size, /^[0-9.]+/);
      val = substr(size, RSTART, RLENGTH) + 0;
      unit = substr(size, RSTART+RLENGTH);
      if (unit == "GB") val = val * 1024;
      sum += val
    } END { printf "%.1f", sum }')

PERCENT=$(awk -v total="$TOTAL_BYTES" -v budget="$BUDGET_MB" 'BEGIN { printf "%.2f", (total/budget)*100 }')

echo "=== Resumen ==="
echo "Peso total de las 5 imágenes: ~${TOTAL_BYTES} MB"
echo "Presupuesto asignado:         ${BUDGET_MB} MB"
echo "Porcentaje utilizado:         ${PERCENT}%"
