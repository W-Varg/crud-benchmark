#!/bin/bash
# Muestra el consumo de RAM de cada servicio del benchmark (sumando todas
# sus réplicas) y qué % representa de tu presupuesto total (10 GB por defecto).
#
# Uso: ./check-ram.sh [budget_en_MB]
#      ./check-ram.sh 10240   # 10 GB

BUDGET_MB=${1:-10240}
NAMESPACE="crud-benchmark"

echo "=== Consumo de RAM por servicio (suma de réplicas) - $(date '+%H:%M:%S') ==="
printf "%-15s %10s %10s\n" "SERVICIO" "RAM(MiB)" "% de ${BUDGET_MB}MB"

TOTAL=0
for app in go-crud rust-crud python-crud bun-crud nestjs-crud; do
  MEM=$(kubectl top pods -n "$NAMESPACE" --no-headers 2>/dev/null \
    | grep "^${app}-" \
    | awk '{ gsub(/Mi/,"",$3); sum += $3 } END { print sum+0 }')

  if [ -n "$MEM" ] && [ "$MEM" != "0" ]; then
    PCT=$(awk -v m="$MEM" -v b="$BUDGET_MB" 'BEGIN { printf "%.2f", (m/b)*100 }')
    printf "%-15s %10s %9s%%\n" "$app" "$MEM" "$PCT"
    TOTAL=$(awk -v t="$TOTAL" -v m="$MEM" 'BEGIN { print t+m }')
  fi
done

echo "-------------------------------------------"
TOTAL_PCT=$(awk -v t="$TOTAL" -v b="$BUDGET_MB" 'BEGIN { printf "%.2f", (t/b)*100 }')
printf "%-15s %10s %9s%%\n" "TOTAL" "$TOTAL" "$TOTAL_PCT"
