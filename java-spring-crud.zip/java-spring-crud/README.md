# CRUD Benchmark - Java + Spring Boot + JPA + MySQL

Implementación en Java del CRUD de productos usado como benchmark comparativo contra Go, Rust, Python, Bun/Elysia y NestJS. **No necesitas instalar Java ni Maven en tu equipo** — todo el build ocurre dentro del contenedor Docker (multi-stage).

## Stack

- **Framework:** Spring Boot 3.3 (Java 21)
- **Base de datos:** MySQL, vía Spring Data JPA + Hibernate + `mysql-connector-j`
- **Validación:** `jakarta.validation` (`@NotBlank`, `@Min`, etc. — equivalente a `class-validator` de NestJS)
- **Documentación:** springdoc-openapi, Swagger montado en `/api`
- **Pool de conexiones:** HikariCP (viene incluido por defecto con `spring-boot-starter-data-jpa`)

## Variables de entorno (`.env`)

```dotenv
ENV_URL_MYSQL_DB=mysql://root:my-secret-pw@127.0.0.1:3306/crud_benchmark
APP_PORT=8086
```

Igual que en Go, el driver JDBC de MySQL **no** acepta la URL `mysql://...` directamente — espera `jdbc:mysql://host:port/db?...`. Por eso `DataSourceConfig.java` parsea `ENV_URL_MYSQL_DB` manualmente (mismo patrón que `buildDSNFromURL` en el proyecto de Go) y construye el `DataSource` a mano con HikariCP.

## Preparar la base de datos

Si ya tienes `crud_benchmark` creada (de los proyectos anteriores), no necesitas hacer nada más — la tabla `products` se crea/actualiza sola al arrancar (`spring.jpa.hibernate.ddl-auto: update`, equivalente al `AutoMigrate` de Go).

Si es la primera vez:

```sql
CREATE DATABASE IF NOT EXISTS crud_benchmark CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

## Build y ejecución — todo con Docker, sin instalar Java

```bash
# Construir la imagen (compila dentro del contenedor con Maven + JDK 21)
docker build -t java_crud .

# Correr contra tu MySQL local
docker run -d -p 8086:8086 \
  --add-host=host.docker.internal:host-gateway \
  -e ENV_URL_MYSQL_DB="mysql://root:my-secret-pw@host.docker.internal:3306/crud_benchmark" \
  -e APP_PORT=8086 \
  --name java_crud \
  java_crud
```

El primer build va a tardar más que los otros lenguajes (Maven descarga todo el ecosistema de Spring Boot), pero solo la primera vez — las capas de Docker quedan cacheadas para builds posteriores.

Verifica los logs:

```bash
docker logs -f java_crud
```

Deberías ver:
```
✅ Conexión a MySQL establecida correctamente
🚀 Servidor Java + Spring Boot escuchando en el puerto 8086
📘 Swagger UI disponible en http://localhost:8086/api
```

## Swagger

Abre en el navegador:

```
http://localhost:8086/api
```

El JSON del esquema OpenAPI está en `http://localhost:8086/api-docs`.

## Probar los endpoints con curl

```bash
# Crear producto
curl -X POST http://localhost:8086/products \
  -H "Content-Type: application/json" \
  -d '{"name":"Impresora láser","price":450.00,"stock":5}'

# Listar todos
curl http://localhost:8086/products

# Obtener por ID
curl http://localhost:8086/products/1

# Actualizar (campos parciales, todos opcionales)
curl -X PUT http://localhost:8086/products/1 \
  -H "Content-Type: application/json" \
  -d '{"stock":20}'

# Eliminar
curl -X DELETE http://localhost:8086/products/1

# Health check
curl http://localhost:8086/health
```

## Desplegar en tu clúster k3d

```bash
# 1. Importar la imagen al clúster
k3d image import java_crud:latest -c crud-benchmark

# 2. Aplicar el manifiesto (ya incluido en este proyecto)
kubectl apply -f 05-java-crud.yaml

# 3. Verificar
kubectl get pods -n crud-benchmark
kubectl top pods -n crud-benchmark
```

Nota que en el manifiesto el `livenessProbe` tiene `initialDelaySeconds: 20` (contra 3 en Go/Rust) — la JVM tarda más en arrancar que un binario nativo, así que necesita más margen antes de que Kubernetes empiece a chequear el `/health`. Este es, de hecho, otro dato de comparación interesante para tu exposición: **tiempo de arranque en frío**.

## Estructura del proyecto

```
java-spring-crud/
├── pom.xml
├── .env
├── .gitignore
├── Dockerfile
├── 05-java-crud.yaml        # manifiesto k8s (Deployment + Service)
├── README.md
└── src/main/
    ├── resources/
    │   └── application.yml  # puerto, ruta de Swagger, pool de conexiones
    └── java/com/benchmark/javacrud/
        ├── JavaCrudApplication.java   # clase principal
        ├── config/
        │   └── DataSourceConfig.java  # parsea ENV_URL_MYSQL_DB → JDBC URL
        ├── model/
        │   └── Product.java           # entidad JPA
        ├── repository/
        │   └── ProductRepository.java # JpaRepository<Product, Long>
        ├── dto/
        │   ├── CreateProductDto.java
        │   └── UpdateProductDto.java
        ├── service/
        │   └── ProductService.java    # lógica de negocio
        ├── controller/
        │   ├── ProductController.java # los 5 endpoints CRUD
        │   └── HealthController.java  # GET /health
        └── exception/
            ├── ResourceNotFoundException.java
            └── GlobalExceptionHandler.java  # maneja 404 y errores de validación
```

## Nota de validación

En este entorno se instalaron Java 21 y Maven, y se confirmó que `pom.xml` es válido y el proyecto intenta compilar correctamente. No pude completar el build porque Maven necesita descargar las dependencias de Spring Boot desde Maven Central, dominio no accesible en este sandbox — eso se resuelve solo con `docker build` corriendo en tu equipo con tu conexión a internet normal, y no debería darte ningún problema porque es exactamente el flujo estándar de cualquier proyecto Spring Boot.

## Con esto se completa el benchmark de 6 lenguajes

| # | Stack | Puerto |
|---|-------|--------|
| 1 | Go + Gin + GORM | 8081 |
| 2 | Rust + Axum + sqlx | 8082 |
| 3 | Python + FastAPI + SQLAlchemy | 8083 |
| 4 | Bun + Elysia + Drizzle | 8084 |
| 5 | NestJS + Fastify + Prisma | 8085 |
| 6 | **Java + Spring Boot + JPA** | **8086** |

Todos comparten el mismo modelo `Product` contra la misma base MySQL `crud_benchmark`, y todos exponen Swagger en `/api`.
