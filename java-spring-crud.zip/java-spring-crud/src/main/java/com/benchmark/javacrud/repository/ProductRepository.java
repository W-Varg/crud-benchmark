package com.benchmark.javacrud.repository;

import com.benchmark.javacrud.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
}
