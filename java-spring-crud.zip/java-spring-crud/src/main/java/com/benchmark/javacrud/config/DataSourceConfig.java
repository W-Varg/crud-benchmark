package com.benchmark.javacrud.config;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.net.URI;

/**
 * Construye el DataSource a partir de ENV_URL_MYSQL_DB, que llega en formato
 * "mysql://user:pass@host:port/dbname". El driver JDBC de MySQL espera
 * "jdbc:mysql://host:port/dbname?user=...&password=...", por lo que hay que
 * parsear la URL manualmente (mismo patrón usado en la versión de Go).
 */
@Configuration
public class DataSourceConfig {

    @Value("${ENV_URL_MYSQL_DB}")
    private String rawMysqlUrl;

    @Bean
    public DataSource dataSource() {
        URI uri = URI.create(rawMysqlUrl);

        String userInfo = uri.getUserInfo();
        if (userInfo == null || !userInfo.contains(":")) {
            throw new IllegalStateException(
                    "ENV_URL_MYSQL_DB debe incluir usuario y password, ej: mysql://user:pass@host:port/db");
        }

        String[] credentials = userInfo.split(":", 2);
        String username = credentials[0];
        String password = credentials[1];

        String host = uri.getHost();
        int port = uri.getPort() == -1 ? 3306 : uri.getPort();
        String database = uri.getPath().replaceFirst("^/", "");

        String jdbcUrl = String.format(
                "jdbc:mysql://%s:%d/%s?useSSL=false&allowPublicKeyRetrieval=true&characterEncoding=UTF-8&serverTimezone=UTC",
                host, port, database);

        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(jdbcUrl);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");

        return dataSource;
    }
}
