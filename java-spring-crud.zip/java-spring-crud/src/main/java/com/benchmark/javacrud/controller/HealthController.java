package com.benchmark.javacrud.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@Tag(name = "health")
@RestController
public class HealthController {

    @GetMapping("/health")
    public Map<String, String> check() {
        return Map.of("status", "ok");
    }
}
