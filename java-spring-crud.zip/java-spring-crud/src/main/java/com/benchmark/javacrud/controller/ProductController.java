package com.benchmark.javacrud.controller;

import com.benchmark.javacrud.dto.CreateProductDto;
import com.benchmark.javacrud.dto.UpdateProductDto;
import com.benchmark.javacrud.model.Product;
import com.benchmark.javacrud.service.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "products")
@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @Operation(summary = "Crear producto")
    @PostMapping
    public ResponseEntity<Product> create(@Valid @RequestBody CreateProductDto dto) {
        Product created = productService.create(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @Operation(summary = "Listar productos")
    @GetMapping
    public List<Product> findAll() {
        return productService.findAll();
    }

    @Operation(summary = "Obtener producto por ID")
    @GetMapping("/{id}")
    public Product findOne(@PathVariable Long id) {
        return productService.findById(id);
    }

    @Operation(summary = "Actualizar producto")
    @PutMapping("/{id}")
    public Product update(@PathVariable Long id, @Valid @RequestBody UpdateProductDto dto) {
        return productService.update(id, dto);
    }

    @Operation(summary = "Eliminar producto")
    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        productService.delete(id);
        return ResponseEntity.ok().body(java.util.Map.of("message", "Producto eliminado correctamente"));
    }
}
