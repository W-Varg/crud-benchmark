package com.benchmark.javacrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaCrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(JavaCrudApplication.class, args);

        String port = System.getenv().getOrDefault("APP_PORT", "8086");
        System.out.println("✅ Conexión a MySQL establecida correctamente");
        System.out.println("🚀 Servidor Java + Spring Boot escuchando en el puerto " + port);
        System.out.println("📘 Swagger UI disponible en http://localhost:" + port + "/api");
    }
}
