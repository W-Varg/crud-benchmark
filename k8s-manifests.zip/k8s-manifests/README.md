# Manifiestos Kubernetes - CRUD Benchmark

Manifiestos para desplegar `go_crud`, `rust_crud`, `python_crud` y `bun_crud` en un clúster k3d local, gestionables con k9s. `nestjs_crud` se agrega después con el mismo patrón (archivo `05-nestjs-crud.yaml`, puerto 8085).

## 1. Crear el clúster

```bash
k3d cluster create crud-benchmark \
  --api-port 6550 \
  -p "8081-8085:8081-8085@loadbalancer" \
  --agents 1
```

## 2. Importar tus imágenes locales

```bash
k3d image import bun_crud python_crud rust_crud go_crud -c crud-benchmark
```

Cada vez que reconstruyas una imagen (`docker build ...`), tienes que volver a importarla con este mismo comando para que el clúster vea la versión nueva.

## 3. Aplicar los manifiestos

```bash
kubectl apply -f 00-namespace.yaml
kubectl apply -f 01-go-crud.yaml
kubectl apply -f 02-rust-crud.yaml
kubectl apply -f 03-python-crud.yaml
kubectl apply -f 04-bun-crud.yaml

# o todo de una vez:
kubectl apply -f .
```

## 4. Verificar que todo esté arriba

```bash
kubectl get pods -n crud-benchmark
kubectl get deployments -n crud-benchmark
kubectl get services -n crud-benchmark
```

## 5. Gestionar con k9s

```bash
k9s -n crud-benchmark
```

Dentro de k9s:
- `:pods` — ver los pods corriendo, logs (`l`), shell (`s`), describe (`d`)
- `:deploy` — ver los deployments; con uno seleccionado, `Ctrl+s` abre el diálogo para **escalar réplicas** en vivo
- `:svc` — ver los services y sus puertos expuestos

## 6. Probar que responden (desde tu Ubuntu, fuera del clúster)

```bash
curl http://localhost:8081/health   # Go
curl http://localhost:8082/health   # Rust
curl http://localhost:8083/health   # Python
curl http://localhost:8084/health   # Bun/Elysia
```

## 7. Escalar réplicas (para la demo en vivo)

Por línea de comandos:

```bash
kubectl scale deployment go-crud --replicas=3 -n crud-benchmark
```

O desde k9s: selecciona el deployment en la vista `:deploy` y presiona `Ctrl+s`.

## 8. Ver consumo de recursos en vivo

```bash
kubectl top pods -n crud-benchmark
```

Si te da error de "metrics not available", falta el metrics-server (k3d no lo trae por defecto):

```bash
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml
kubectl patch deployment metrics-server -n kube-system --type='json' \
  -p='[{"op":"add","path":"/spec/template/spec/containers/0/args/-","value":"--kubelet-insecure-tls"}]'
```

(El flag `--kubelet-insecure-tls` es necesario porque los certificados de k3d son autofirmados; solo para tu entorno local de pruebas.)

## 9. Actualizar una imagen ya desplegada

Cuando reconstruyas un CRUD (ej. después de un cambio de código):

```bash
docker build -t go_crud:latest ./go-gin-crud
k3d image import go_crud:latest -c crud-benchmark
kubectl rollout restart deployment go-crud -n crud-benchmark
```

## 10. Limpiar todo al terminar

```bash
kubectl delete namespace crud-benchmark
k3d cluster delete crud-benchmark
```

## Notas importantes

- `host.k3d.internal` es el hostname que k3d expone automáticamente hacia tu máquina host — así los pods pueden llegar a tu MySQL local sin configuración extra (equivalente a `host.docker.internal`).
- Los `Service` son de tipo `LoadBalancer`: k3d ya trae un contenedor *serverlb* que enruta esos puertos hacia el host gracias al `-p "8081-8085:8081-8085@loadbalancer"` que usaste al crear el clúster.
- Los `resources.limits` (`cpu: 1000m`, `memory: 256Mi`) igualan los límites que definimos en el `docker-compose.yml` original, para que la comparación de recursos siga siendo justa incluso corriendo en Kubernetes.
