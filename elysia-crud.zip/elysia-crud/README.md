# CRUD Benchmark - Bun + Elysia + Drizzle ORM + MySQL

Implementación en Bun/Elysia del CRUD de productos usado como benchmark comparativo contra Go, Rust, Python y NestJS.

## Stack

- **Runtime:** [Bun](https://bun.sh/)
- **Framework:** [Elysia](https://elysiajs.com/) 1.x
- **Base de datos:** MySQL, vía [Drizzle ORM](https://orm.drizzle.team/) + driver `mysql2`
- **Documentación:** `@elysiajs/swagger` (genera el esquema OpenAPI automáticamente a partir de los tipos `t.Object(...)` de cada ruta)

## Variables de entorno (`.env`)

```dotenv
ENV_URL_MYSQL_DB=mysql://root:my-secret-pw@127.0.0.1:3306/crud_benchmark
APP_PORT=8084
```

Igual que en Rust, `mysql2` acepta la URL `mysql://...` **directamente** vía la opción `uri`, sin necesidad de parsearla manualmente (a diferencia de Go y Python, que sí requieren conversión).

## Preparar la base de datos

Si ya tienes `crud_benchmark` creada (de los proyectos anteriores), no necesitas hacer nada más — la tabla `products` se crea sola al arrancar (`ensureTable()`, equivalente al `AutoMigrate` de Go o el `CREATE TABLE IF NOT EXISTS` de Rust/Python).

Si es la primera vez:

```sql
CREATE DATABASE IF NOT EXISTS crud_benchmark CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

## Correr en local

```bash
bun install
bun run start
# o en modo desarrollo con recarga automática:
bun run dev
```

Deberías ver:
```
✅ Conexión a MySQL establecida y tabla verificada correctamente
🚀 Servidor Bun + Elysia escuchando en el puerto 8084
📘 Swagger UI disponible en http://localhost:8084/api
```

## Swagger

Abre en el navegador:

```
http://localhost:8084/api
```

El JSON del esquema OpenAPI está en `http://localhost:8084/api/json`.

## Probar los endpoints con curl

```bash
# Crear producto
curl -X POST http://localhost:8084/products \
  -H "Content-Type: application/json" \
  -d '{"name":"Teclado mecánico","price":89.90,"stock":15}'

# Listar todos
curl http://localhost:8084/products

# Obtener por ID
curl http://localhost:8084/products/1

# Actualizar (campos parciales, todos opcionales)
curl -X PUT http://localhost:8084/products/1 \
  -H "Content-Type: application/json" \
  -d '{"stock":30}'

# Eliminar
curl -X DELETE http://localhost:8084/products/1

# Health check
curl http://localhost:8084/health
```

## Docker

```bash
docker build -t crud-elysia .

docker run -d -p 8084:8084 \
  --add-host=host.docker.internal:host-gateway \
  -e ENV_URL_MYSQL_DB="mysql://root:my-secret-pw@host.docker.internal:3306/crud_benchmark" \
  -e APP_PORT=8084 \
  crud-elysia
```

El `--add-host` es necesario porque MySQL corre en tu máquina host, no en un contenedor; sin ese flag, el contenedor no puede alcanzar `127.0.0.1` de tu equipo.

## Estructura del proyecto

```
elysia-crud/
├── package.json
├── tsconfig.json
├── bun.lock
├── .env
├── .gitignore
├── Dockerfile
├── README.md
└── src/
    ├── index.ts          # entry point, registra swagger, health check y rutas
    ├── db/
    │   ├── client.ts     # conexión a MySQL (pool mysql2) + ensureTable()
    │   └── schema.ts      # schema de Drizzle para la tabla products
    └── routes/
        └── products.ts    # los 5 endpoints CRUD con validación t.Object
```

## Validado en este entorno

Este proyecto fue probado de punta a punta en el sandbox: se instaló Bun, se levantó un servidor MySQL real, y se ejecutaron los 5 endpoints CRUD + `/health` + `/api` (Swagger) contra la base de datos, confirmando que todo responde correctamente.
