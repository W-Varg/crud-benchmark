import { eq } from "drizzle-orm";
import { Elysia, t } from "elysia";
import { db } from "../db/client";
import { products } from "../db/schema";

const ProductCreateBody = t.Object({
  name: t.String({ maxLength: 150, examples: ["Laptop"] }),
  price: t.Number({ minimum: 0.01, examples: [1200.5] }),
  stock: t.Integer({ minimum: 0, examples: [10] }),
});

const ProductUpdateBody = t.Object({
  name: t.Optional(t.String({ maxLength: 150 })),
  price: t.Optional(t.Number({ minimum: 0.01 })),
  stock: t.Optional(t.Integer({ minimum: 0 })),
});

const IdParams = t.Object({
  id: t.String(),
});

export const productsRoutes = new Elysia({ prefix: "/products", tags: ["products"] })
  .post(
    "/",
    async ({ body, set }) => {
      const [result] = await db.insert(products).values(body);
      const [created] = await db
        .select()
        .from(products)
        .where(eq(products.id, result.insertId));

      set.status = 201;
      return created;
    },
    {
      body: ProductCreateBody,
      detail: { summary: "Crear producto" },
    }
  )

  .get(
    "/",
    async () => {
      return db.select().from(products);
    },
    {
      detail: { summary: "Listar productos" },
    }
  )

  .get(
    "/:id",
    async ({ params, set }) => {
      const id = Number(params.id);
      const [product] = await db.select().from(products).where(eq(products.id, id));

      if (!product) {
        set.status = 404;
        return { error: "Producto no encontrado" };
      }

      return product;
    },
    {
      params: IdParams,
      detail: { summary: "Obtener producto por ID" },
    }
  )

  .put(
    "/:id",
    async ({ params, body, set }) => {
      const id = Number(params.id);
      const [existing] = await db.select().from(products).where(eq(products.id, id));

      if (!existing) {
        set.status = 404;
        return { error: "Producto no encontrado" };
      }

      await db.update(products).set(body).where(eq(products.id, id));
      const [updated] = await db.select().from(products).where(eq(products.id, id));

      return updated;
    },
    {
      params: IdParams,
      body: ProductUpdateBody,
      detail: { summary: "Actualizar producto" },
    }
  )

  .delete(
    "/:id",
    async ({ params, set }) => {
      const id = Number(params.id);
      const [existing] = await db.select().from(products).where(eq(products.id, id));

      if (!existing) {
        set.status = 404;
        return { error: "Producto no encontrado" };
      }

      await db.delete(products).where(eq(products.id, id));
      return { message: "Producto eliminado correctamente" };
    },
    {
      params: IdParams,
      detail: { summary: "Eliminar producto" },
    }
  );
