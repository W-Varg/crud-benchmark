import { bigint, double, int, mysqlTable, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Entidad Product tal como se almacena en MySQL.
 * Se mantiene idéntica en estructura a las versiones de Go, Python,
 * Rust y NestJS para que la comparación de benchmark sea justa.
 */
export const products = mysqlTable("products", {
  id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  name: varchar("name", { length: 150 }).notNull(),
  price: double("price").notNull(),
  stock: int("stock").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
});

export type Product = typeof products.$inferSelect;
export type NewProduct = typeof products.$inferInsert;
