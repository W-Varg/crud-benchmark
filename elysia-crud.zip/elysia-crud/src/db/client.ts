import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import * as schema from "./schema";

const connectionString = process.env.ENV_URL_MYSQL_DB;

if (!connectionString) {
  throw new Error("La variable de entorno ENV_URL_MYSQL_DB no está definida");
}

// mysql2 acepta la URL "mysql://user:pass@host:port/db" directamente,
// igual que sqlx en Rust — no hace falta parsearla como en Go.
const pool = mysql.createPool({
  uri: connectionString,
  connectionLimit: 50,
});

export const db = drizzle(pool, { schema, mode: "default" });

/**
 * Crea la tabla si no existe. Equivalente al AutoMigrate de GORM (Go)
 * o al CREATE TABLE IF NOT EXISTS de sqlx (Rust).
 */
export async function ensureTable(): Promise<void> {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS products (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(150) NOT NULL,
      price DOUBLE NOT NULL,
      stock INT NOT NULL DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )
  `);

  console.log("✅ Conexión a MySQL establecida y tabla verificada correctamente");
}
