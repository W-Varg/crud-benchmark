import { swagger } from "@elysiajs/swagger";
import { Elysia } from "elysia";
import { ensureTable } from "./db/client";
import { productsRoutes } from "./routes/products";

const PORT = Number(process.env.APP_PORT) || 8084;

await ensureTable();

const app = new Elysia()
  .use(
    swagger({
      path: "/api",
      documentation: {
        info: {
          title: "CRUD Benchmark API - Bun + Elysia + Drizzle + MySQL",
          version: "1.0.0",
          description:
            "API CRUD de productos usada como benchmark de rendimiento entre Go, Python, NestJS, Rust y Elysia.",
        },
        tags: [{ name: "products", description: "Operaciones CRUD sobre productos" }],
      },
    })
  )
  .get("/health", () => ({ status: "ok" }))
  .use(productsRoutes)
  .listen(PORT);

console.log(`🚀 Servidor Bun + Elysia escuchando en el puerto ${PORT}`);
console.log(`📘 Swagger UI disponible en http://localhost:${PORT}/api`);

export type App = typeof app;
